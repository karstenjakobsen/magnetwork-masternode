Magnet-qt: Qt5 GUI for Magnet
===============================

Linux
-------
https://github.com/magnetwork/magnet/blob/master/doc/build-unix.md

Windows
--------
https://github.com/magnetwork/magnet/blob/master/doc/build-msw.md

Mac OS X
--------
https://github.com/magnetwork/magnet/blob/master/doc/build-osx.md
